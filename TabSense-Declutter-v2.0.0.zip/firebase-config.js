const firebaseConfig = {
    apiKey: "AIzaSyDkAxvui00Uo_L3-1nugF8to_TG6Qu4uPI",
    authDomain: "tabsense-14916.firebaseapp.com",
    projectId: "tabsense-14916",
    storageBucket: "tabsense-14916.firebasestorage.app",
    messagingSenderId: "853012985837",
    appId: "1:853012985837:web:3400cff5c36788a843d9e4",
    measurementId: "G-4NPLFJ1JVF"
};