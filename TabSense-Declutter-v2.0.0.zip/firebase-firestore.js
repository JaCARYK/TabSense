export { 
    getFirestore, 
    collection, 
    doc, 
    setDoc, 
    getDoc,
    updateDoc,
    deleteDoc,
    query,
    where,
    orderBy,
    limit
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';